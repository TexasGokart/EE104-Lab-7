Name: Tejas Gokarn
Class: EE104 Section 01

GitHub Link: https://github.com/TexasGokart/EE104-Lab-7

----------[(Facial Recognition Model)]----------
This project involved using the YOLOv8 algorithm to train a model to recognize objects and people based on custom image datasets. The steps involved include labeling the images with bounding boxes and training the YOLOv8 model using the labeled dataset.

Prerequisite steps:
1. git clone https://github.com/ivangrov/ModifiedOpenLabelling.git
2. Place the images to be labeled in the images folder
3. pip install -r requirements.txt
4. python run.py
5. Delete labeling mistakes



----------[(Sleeping Dragons Game)]----------

***REQUIRED PYTHON LIBRARIES***
import math
import pgzrun
import pygame
import pgzero
import sys
import random
from pgzero.builtins import Actor
from random import randint

***ABOUT THIS CODE***
This code is a game where you control two heroes (one with WASD and the other with arrow keys), trying to collect dragon eggs while avoiding the dragons' random attacks. Losing all six of your lives means GAME OVER while collecting twenty eggs means GAME WIN. 